function welcome(name) {
  console.log(`"안녕하세요"${name}님!`);
}

welcome("코드잇");

function printSquare(x) {
  console.log(x * x);
}

printSquare(5);
